package kr.ac.korea.intelligentgallery.listener;

import android.view.View;

/**
 * @author hyojoong2
 */
public interface AdapterItemClickListener {
	public void onAdapterItemClick(View view, int position);
	
}
