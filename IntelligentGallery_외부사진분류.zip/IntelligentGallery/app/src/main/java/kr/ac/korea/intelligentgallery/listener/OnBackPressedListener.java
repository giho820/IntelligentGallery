package kr.ac.korea.intelligentgallery.listener;

/**
 * Created by kiho on 2016. 1. 7..
 */
public interface OnBackPressedListener {
    void onBackPressed();
}
