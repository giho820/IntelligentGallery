package kr.ac.korea.intelligentgallery.listener;


import kr.ac.korea.intelligentgallery.data.ImageFile;

/**
 * Created by kiho on 2015. 12. 10..
 */
public interface ViewItemListener {
    public void onSendViewItemData(ImageFile item);
}
