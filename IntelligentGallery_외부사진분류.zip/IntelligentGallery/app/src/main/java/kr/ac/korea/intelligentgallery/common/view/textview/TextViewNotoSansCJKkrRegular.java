package kr.ac.korea.intelligentgallery.common.view.textview;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.TextView;

import kr.ac.korea.intelligentgallery.util.TextUtil;

public class TextViewNotoSansCJKkrRegular extends TextView {

    public TextViewNotoSansCJKkrRegular(Context context, AttributeSet attrs) {
        super(context, attrs);
        if (TextUtil.NotoSansCJKkrRegular != null)
            setTypeface(TextUtil.NotoSansCJKkrRegular);
    }

    public TextViewNotoSansCJKkrRegular(Context context) {
        super(context);
        if (TextUtil.NotoSansCJKkrRegular != null)
            setTypeface(TextUtil.NotoSansCJKkrRegular);
    }

    public TextViewNotoSansCJKkrRegular(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        if (TextUtil.NotoSansCJKkrRegular != null)
            setTypeface(TextUtil.NotoSansCJKkrRegular);
    }

}
