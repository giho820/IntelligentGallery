package com.example.dilab.sampledilabapplication.Sample;

import android.content.Context;

/**
 * Created by shysi on 2016-01-04.
 */
public class SampleResourceInitializer {
    public void initialize(Context context){

    }
}
