package kr.ac.korea.intelligentgallery.listener;

/**
 * Created by kiho on 2016. 1. 21..
 */
public interface OnPhotoViewClickedListener {
    public void onPhotoViewClicked(boolean isClicked);
}
