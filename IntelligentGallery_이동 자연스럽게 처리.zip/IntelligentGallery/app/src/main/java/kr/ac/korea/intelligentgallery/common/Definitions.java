package kr.ac.korea.intelligentgallery.common;

/**
 * Created by kiho on 2015. 12. 21..
 */
public class Definitions {
    public interface INPUT_TYPE {
        int MAIN = 0;
        int FOLDER_FRAGMENT = 1;
        int CATEGORY_FRAGMENT = 2;
    }

    public interface DIALOG_TYPE {
        int DITERMIN_MAKING_CONTEXT_DB_OR_NOT = 0;
        int RENAMING = 1;
        int ADDING = 2;
        int SEARCHING = 3;
    }


}
