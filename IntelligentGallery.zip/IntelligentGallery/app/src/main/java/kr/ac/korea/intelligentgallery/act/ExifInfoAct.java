package kr.ac.korea.intelligentgallery.act;

import kr.ac.korea.intelligentgallery.common.ParentAct;

/**
 * Created by kiho on 2016. 1. 21..
 */
public class ExifInfoAct extends ParentAct{

}
