package kr.ac.korea.intelligentgallery.listener;

import android.content.DialogInterface;

/**
 * Created by preparkha on 2015. 11. 17..
 */
public interface CommonDialogListener {

    public void onClickCommonDialog(DialogInterface dialog, int which, String newFolderName);

}
